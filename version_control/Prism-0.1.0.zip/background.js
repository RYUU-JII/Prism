const latestByTab = new Map();
const panelOpenByTab = new Map();
function storeLatest(tabId, payload) {
latestByTab.set(tabId, {
code: payload.code || "",
language: payload.language || "text",
url: payload.url || "",
theme: payload.theme || "light"
});
}
function isPanelOpen(tabId) {
return panelOpenByTab.get(tabId) === true;
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
const tabId = sender?.tab?.id ?? message.tabId ?? "_global";
if (message?.type === "OPEN_PRISM") {
const payload = {
code: message.code || "",
language: message.language || "text",
url: sender?.tab?.url || message.url || "",
theme: message.theme || "light"
};
storeLatest(tabId, payload);
panelOpenByTab.set(tabId, true);
const sendRender = () => {
chrome.runtime.sendMessage({ type: "PRISM_RENDER", tabId, ...payload }, () => {
if (chrome.runtime?.lastError) {  }
});
};
if (sender?.tab?.id !== undefined && chrome.sidePanel?.open) {
chrome.sidePanel.open({ tabId: sender.tab.id })
.then(() => setTimeout(sendRender, 300))
.catch(() => setTimeout(sendRender, 300));
} else {
setTimeout(sendRender, 300);
}
sendResponse({ ok: true, open: true });
}
else if (message?.type === "PRISM_RENDER_NOW") {
const payload = {
code: message.code || "",
language: message.language || "text",
url: sender?.tab?.url || message.url || "",
theme: message.theme || "light"
};
storeLatest(tabId, payload);
chrome.runtime.sendMessage({ type: "PRISM_RENDER", tabId, ...payload }, () => {
const err = chrome.runtime?.lastError;
if (err) {
const isOpen = isPanelOpen(tabId);
if (!isOpen) panelOpenByTab.set(tabId, false);
sendResponse({ ok: true, open: isOpen });
} else {
panelOpenByTab.set(tabId, true);
sendResponse({ ok: true, open: true });
}
});
return true;
}
else if (message.type === "PRISM_PANEL_STATUS") {
const statusTabId = message.tabId;
const isOpen = message.open === true;
panelOpenByTab.set(statusTabId, isOpen);
chrome.tabs.sendMessage(statusTabId, {
type: "PRISM_PANEL_STATUS",
open: isOpen
}).catch(() => {  });
sendResponse({ ok: true });
}
else if (message?.type === "PRISM_PANEL_STATUS_REQUEST") {
sendResponse({ ok: true, open: isPanelOpen(tabId) });
}
else if (message?.type === "PRISM_GET_LATEST") {
const targetTabId = message.tabId ?? "_global";
const payload = latestByTab.get(targetTabId) || { code: "", language: "text", url: "" };
sendResponse({ ok: true, payload });
}
else if (message?.type === "PRISM_SET_LATEST") {
const targetTabId = message.tabId ?? "_global";
const payload = message.payload || {};
storeLatest(targetTabId, payload);
if (message.notifyTabId) {
const notifyTabId = message.notifyTabId;
chrome.runtime.sendMessage({ type: "PRISM_RENDER", tabId: targetTabId, ...payload }, () => {
if (chrome.runtime?.lastError) {
}
});
}
sendResponse({ ok: true });
}
else if (message?.type === "PRISM_DEVLOG") {
sendResponse({ ok: true });
}
else if (message.type === "PRISM_PROXY_FETCH") {
fetch(message.url)
.then(response => response.blob())
.then(blob => {
const reader = new FileReader();
reader.onloadend = () => sendResponse({ dataUrl: reader.result });
reader.readAsDataURL(blob);
})
.catch(error => {
console.error("[Prism Proxy] Fetch failed:", error);
sendResponse({ error: error.message });
});
return true;
}
else if (message?.type === "PRISM_RETURN_TO_TAB") {
const targetTabId = message.tabId;
if (!targetTabId) return sendResponse({ ok: false });
chrome.tabs.get(targetTabId, (tab) => {
if (tab?.windowId !== undefined) {
chrome.windows.update(tab.windowId, { focused: true }, () => {
chrome.tabs.update(targetTabId, { active: true }, () => {
if (chrome.sidePanel?.open) {
chrome.sidePanel.open({ tabId: targetTabId }).catch(() => {});
}
});
});
}
});
sendResponse({ ok: true });
}
return true;
});
chrome.runtime.onConnect.addListener((port) => {
if (port.name === "prism-heartbeat") {
let ownerTabId = null;
port.onMessage.addListener((msg) => {
if (msg.tabId) {
ownerTabId = msg.tabId;
panelOpenByTab.set(ownerTabId, true);
}
});
port.onDisconnect.addListener(() => {
if (ownerTabId) {
panelOpenByTab.set(ownerTabId, false);
chrome.tabs.sendMessage(ownerTabId, {
type: "PRISM_PANEL_STATUS",
open: false
}).catch(() => {});
}
});
}
});
chrome.tabs.onRemoved.addListener((tabId) => {
latestByTab.delete(tabId);
panelOpenByTab.delete(tabId);
});
